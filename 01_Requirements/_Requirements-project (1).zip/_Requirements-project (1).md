﻿
**# REQUIREMENTS**

- **#INTRODUCTION:** Project Reportof Contact Management .Abstract of the Project Contact Management System:The purpose of Contact Management System	is to automate the existing manual system  by  the  help  of  computerized  equipments  and  full-fledged  computer  software, fulfilling  their  requirements,  so  that  their  valuable  data/information  can  be  stored  for  a longer period with easy accessing and manipulation of the same. The required software and hardware are easily available and easy to work with.
- **Add new contacts**: with information such as name, phone number, address, and email
- **List all contacts:** lists all the contacts stored in file with their respective contact details
- **Edit contacts**: edit information given while adding the contacts – name, phone number, address, and email

- **Delete contacts:** deletes contacts from file

**Defining System:** 

Design and testing mathematical operations 	Contact Management System	of using unit testing algorithm.

**SWOT analysis:**

**Strengths:**
1. ### **Better, longer-lasting customer relationships**
1. ### **Improved customer experience**


### **3.** **Better alignment and collaboration across teams**

### **4.** **The ability to personalize customer interactions**

### **5.**  **Reduced expenditures**


- **Weakness:** Loss of Service Control. ...
- Potential Time Delays. ...
- Loss of Business Flexibility. ...
- Loss of Product Quality. ...
- Compliance and Legal Issues.


**4’W and 1’H**

**What:** contact management system**     

**Where:** School, Offices, Public	Places, Emergency		

**When:** Need for	Information.

**How:** 
Contact management is **the process of recording contacts' details and tracking their interactions with a business**

**Detail Requirements:**

**High Level Requirements:**

|`      `ID|`                 `Description|`            `Status|
| :- | :- | :- |
|`    `**HL01**|` `Add new contacts|`    `Implemented|
|`    `**HL02**|` `List all contacts|`    `Implemented|
|`    `**HL03**|` `Edit contacts|`    `Implemented|
|`    `**HL04**|Delete contacts|`    `Implemented|

` `**Low level Requirements:**

|`      `**ID**|`                 `**Description**|`            `**Status**|
| :- | :- | :- |
|<p>LL01\_HL01</p><p></p>|Add of contact name, phone number, contact mail|`    `Implemented|
|LL02\_HL02|Displaying of contact numbers by entering contact name|`    `Implemented|
|LL03\_HL03|Modifications can be changes by enter contact name|`    `Implemented|
|LL04|Delete of single contact by enter account name|`    `Implemented|

